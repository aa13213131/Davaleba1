package com.example.davaleba1

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var editTextRecipientNumber: EditText
    private lateinit var editTextMessage: EditText
    private val MAX_MESSAGE_LENGTH = 250

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        editTextRecipientNumber = findViewById(R.id.editTextRecipientNumber)
        editTextMessage = findViewById(R.id.editTextMessage)
        val sendMessageButton: Button = findViewById(R.id.buttonSendMessage)

        sendMessageButton.setOnClickListener {
            val recipientNumber = editTextRecipientNumber.text.toString().trim()
            val message = editTextMessage.text.toString().trim()

            if (isValidRecipientNumber(recipientNumber) && isValidMessage(message)) {
                val intent = Intent(this, SecondActivity::class.java)
                intent.putExtra("recipientNumber", recipientNumber)
                intent.putExtra("message", message)
                startActivity(intent)
            } else {
                Toast.makeText(this, "Please enter a valid number and message.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun isValidRecipientNumber(number: String): Boolean {
        return number.matches(Regex("\\d+"))
    }

    private fun isValidMessage(message: String): Boolean {
        return message.isNotEmpty() && message.length <= MAX_MESSAGE_LENGTH
    }
}

class SecondActivity {

}

open class AppCompatActivity {

}
